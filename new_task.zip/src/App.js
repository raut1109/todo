import './App.css';
import Output from './Components/Output';

function App() {
  return (
     <>
     <Output />
     </>
  );
}

export default App;
