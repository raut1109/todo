import React, { useEffect } from 'react';

const Output = () => {
    useEffect(() => {
        const mockData = [
            "gopal",
            "gopal",
            "gopal",
            "pavan",
            "gopal",
            "raju",
            "gopal",
            "pavan",
            "gopal",
            "raju",
            "pavan",
            "gopal",
            "pavan"
        ];

        const countMap = {};
        for (let i = 0; i < mockData.length; i++) {
            const name = mockData[i];
            countMap[name] = (countMap[name] || 0) + 1;
        }

        const tableBody = document.getElementById("table-body");
        for (let name in countMap) {
            const count = countMap[name];
            const row = document.createElement("tr");
            const nameCell = document.createElement("td");
            const countCell = document.createElement("td");

            nameCell.textContent = name;
            countCell.textContent = count;

            row.appendChild(nameCell);
            row.appendChild(countCell);

            if (count > 0 && count < 3) {
                row.classList.add("red");
            } else if (count >= 3 && count < 10) {
                row.classList.add("yellow");
            } else if (count >= 10) {
                row.classList.add("green");
            }

            tableBody.appendChild(row);
        }
    }, []);

    return (
        <div>
            <head>
                <title>Duplicate Name Table</title>
                <style>
                    {`
          .red {
            background-color: red;
          }

          .yellow {
            background-color: yellow;
          }

          .green {
            background-color: green;
          }
          `}
                </style>
            </head>
            <body>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Occurrences</th>
                    </tr>
                    <tbody id="table-body"></tbody>
                </table>
            </body>
        </div>
    );
};

export default Output;
